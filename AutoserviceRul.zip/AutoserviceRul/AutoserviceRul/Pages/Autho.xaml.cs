﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AutoserviceRul.Entities;

namespace AutoserviceRul.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        private int countUnsuccessful = 0;
        public Autho()
        {
            InitializeComponent();

            txtCaptcha.Visibility = Visibility.Hidden;
            textBlockCaptcha.Visibility = Visibility.Hidden;
        }

        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null));
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            if (countUnsuccessful == 0)
            {
                Enter();
            }
            else if (countUnsuccessful < 3)
            {
                GenerateCaptcha();
                if (txtCaptcha.Text == "ju2sT8Cbs")
                {
                    Enter();
                }
                else if (txtCaptcha.Text == "iNwK2cl")
                {
                    Enter();
                }
                else if (txtCaptcha.Text == "uOozGk95")
                {
                    Enter();
                }
                else if (txtCaptcha.Text.Length == 0)
                {
                    MessageBox.Show("Enter captcha!");
                }
                else
                {
                    MessageBox.Show("Captcha wrong!");
                    countUnsuccessful++;
                }
            }
            else
            {
                MessageBox.Show("Blocked!");
            }
        }
        
        private void Enter()
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();
            User user = new User();
            user = RulEntities.GetContext().User.Where(p => p.UserLogin == login && p.UserPassword == password).FirstOrDefault();
            int userCount = RulEntities.GetContext().User.Where(p => p.UserLogin == login && p.UserPassword == password).Count();

            if (userCount > 0)
            {
                MessageBox.Show("Вы вошли под: " + user.Role.RoleName.ToString());
                LoadForm(user.Role.RoleName.ToString(), user);
            }
            else
            {
                MessageBox.Show("Вы ввели нерно логин или пароль!");
                countUnsuccessful++;
            }
        }
        
        private void GenerateCaptcha()
        {
            txtCaptcha.Visibility = Visibility.Visible;
            textBlockCaptcha.Visibility = Visibility.Visible;

            Random random = new Random();
            int randNum = random.Next(1, 3);

            switch (randNum)
            {
                case 1:
                    textBlockCaptcha.Text = "ju2sT8Cbs";
                    textBlockCaptcha.TextDecorations = TextDecorations.Strikethrough;
                    break;
                case 2:
                    textBlockCaptcha.Text = "iNwK2cl";
                    textBlockCaptcha.TextDecorations = TextDecorations.Strikethrough;
                    break;
                case 3:
                    textBlockCaptcha.Text = "uOozGk95";
                    textBlockCaptcha.TextDecorations = TextDecorations.Strikethrough;
                    break;
            }
        }
        private void LoadForm(string _role, User user)
        {
            switch (_role)
            {
                case "Клиент":
                    NavigationService.Navigate(new Client(user));
                    break;
                case "Менеджер":
                    NavigationService.Navigate(new Client(user));
                    break;
                case "Администратор":
                    NavigationService.Navigate(new Admin(user));
                    break;
            }
        }
    }
}
